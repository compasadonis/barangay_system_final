from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin or staff


class Household(db.Model):
    __tablename__ = "households"

    id = db.Column(db.Integer, primary_key=True)
    household_no = db.Column(db.String(50), unique=True, nullable=False)
    household_name = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(300), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    residents = db.relationship('Resident', backref='household', lazy=True)

    def __repr__(self):
        return f"<Household {self.household_no} - {self.household_name}>"


class Resident(db.Model):
    __tablename__ = "residents"

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=False)
    suffix = db.Column(db.String(20), nullable=True)
    name = db.Column(db.String(200), nullable=True)

    gender = db.Column(db.String(20), nullable=True)
    birthday = db.Column(db.Date, nullable=True)
    birthplace = db.Column(db.String(200), nullable=True)
    civil_status = db.Column(db.String(50), nullable=True)
    phone_number = db.Column(db.String(50), nullable=True)
    address = db.Column(db.String(300), nullable=True)
    registered_voter = db.Column(db.String(10), nullable=True)
    length_of_residency = db.Column(db.Integer, nullable=True)

    relationship_to_head = db.Column(db.String(50), nullable=True)
    is_household_head = db.Column(db.Boolean, default=False)
    household_id = db.Column(db.Integer, db.ForeignKey('households.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    barangay_ids = db.relationship('BarangayID', backref='resident', lazy=True)
    clearances = db.relationship('Clearance', backref='resident', lazy=True)
    indigencies = db.relationship('Indigency', backref='resident', lazy=True)
    good_morals = db.relationship('GoodMoral', backref='resident', lazy=True)
    first_job_seekers = db.relationship('FirstJobSeeker', backref='resident', lazy=True)

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name, self.suffix]
        return " ".join([p for p in parts if p]).strip()

    def __repr__(self):
        return f"<Resident {self.full_name}>"


class BarangayID(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=True)
    household_id = db.Column(db.Integer, db.ForeignKey('households.id'), nullable=True)

    name = db.Column(db.String(200), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    suffix = db.Column(db.String(20), nullable=True)
    relationship_to_head = db.Column(db.String(50), nullable=True)

    address = db.Column(db.String(300))
    phone_number = db.Column(db.String(50))
    gender = db.Column(db.String(20))
    registered_voter = db.Column(db.String(5))
    nonreg_proof = db.Column(db.String(300))
    birthday = db.Column(db.Date)
    purpose = db.Column(db.String(300))
    status = db.Column(db.String(50))
    date_issued = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    household = db.relationship('Household', lazy='joined')

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name, self.suffix]
        built = " ".join([p for p in parts if p]).strip()
        return built or (self.name or "")


class Clearance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=True)
    household_id = db.Column(db.Integer, db.ForeignKey('households.id'), nullable=True)

    name = db.Column(db.String(200), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    suffix = db.Column(db.String(20), nullable=True)
    relationship_to_head = db.Column(db.String(50), nullable=True)

    address = db.Column(db.String(300))
    phone_number = db.Column(db.String(50))
    birthday = db.Column(db.Date)
    birthplace = db.Column(db.String(200))
    gender = db.Column(db.String(20))
    civil_status = db.Column(db.String(50))
    purpose = db.Column(db.String(300))
    status = db.Column(db.String(50))
    date_issued = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    household = db.relationship('Household', lazy='joined')

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name, self.suffix]
        built = " ".join([p for p in parts if p]).strip()
        return built or (self.name or "")


class Indigency(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=True)
    household_id = db.Column(db.Integer, db.ForeignKey('households.id'), nullable=True)

    name = db.Column(db.String(200), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    suffix = db.Column(db.String(20), nullable=True)
    relationship_to_head = db.Column(db.String(50), nullable=True)

    address = db.Column(db.String(300))
    gender = db.Column(db.String(20))
    purpose = db.Column(db.String(300))
    status = db.Column(db.String(50))
    date_issued = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    household = db.relationship('Household', lazy='joined')

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name, self.suffix]
        built = " ".join([p for p in parts if p]).strip()
        return built or (self.name or "")


class GoodMoral(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=True)
    household_id = db.Column(db.Integer, db.ForeignKey('households.id'), nullable=True)

    name = db.Column(db.String(200), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    suffix = db.Column(db.String(20), nullable=True)
    relationship_to_head = db.Column(db.String(50), nullable=True)

    address = db.Column(db.String(300))
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(20))
    civil_status = db.Column(db.String(50))
    length_of_residency = db.Column(db.Integer)
    purpose = db.Column(db.String(300))
    status = db.Column(db.String(50))
    date_issued = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    household = db.relationship('Household', lazy='joined')

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name, self.suffix]
        built = " ".join([p for p in parts if p]).strip()
        return built or (self.name or "")


class FirstJobSeeker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=True)
    household_id = db.Column(db.Integer, db.ForeignKey('households.id'), nullable=True)

    name = db.Column(db.String(200), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    middle_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    suffix = db.Column(db.String(20), nullable=True)
    relationship_to_head = db.Column(db.String(50), nullable=True)

    address = db.Column(db.String(300))
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(20))
    length_of_residency = db.Column(db.Integer)
    date_issued = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    household = db.relationship('Household', lazy='joined')

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name, self.suffix]
        built = " ".join([p for p in parts if p]).strip()
        return built or (self.name or "")


class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(200), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    table_name = db.Column(db.String(100), nullable=False)
    record_id = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
